# Zachary Tueller
# CS1400 - MO1
# Assignment 1
from task1 import *;import turtle as t

if __name__ == '__main__':
    task1() # reference task1 module per python best practices
    code = input("Exit? Y/N: ") # the y/n here probably won't be functional, it's just there to add a stop


