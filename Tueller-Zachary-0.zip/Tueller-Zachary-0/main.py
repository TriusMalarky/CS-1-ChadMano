
# Zachary Tueller
# CS1400 - MO1
# Assignment 0
class core():
    def __init__(self):
        self.name = 'Zachary Tueller'
        self.football_team_of_choice = 'Fighting Irish'



if __name__ == '__main__':
    core = core()
    print('Hello! My name is ' + core.name + '!')

